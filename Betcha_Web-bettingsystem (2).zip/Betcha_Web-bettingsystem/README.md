# Betcha
#### It's Technically Not Gambling

| Task         | Person | Status      |
| ------------ |:------:|:-----------:|
| UI             | Aleks  | In Progress |
| Payment        | Aleks  | Logged      |
| UI             | Ashish | In Progress |
| Filler Text    | Ben    | In Progress |
| Logo           | Ben    | Logged      |
| Security       | Clay   | In Progress |
| Database       | Max    | In Progress |
| Authentication | Max    | Logged      |
| Chat           | Max    | Complete    |
| Twitch Embed   | Max    | Complete    |
| Betting System | Sean   | In Progress |
